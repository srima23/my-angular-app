import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthService } from '../AuthService';

import { CartService } from '../cart.service'; // Create a CartService to manage the cart items.

 

@Component({

  selector: 'app-cartpage',

  templateUrl: './cartpage.component.html',

  styleUrls: ['./cartpage.component.css']

})

export class CartpageComponent {

  cartItems: any[] = [];

  constructor(private cart: CartService ,private _http: HttpClient, private head: AuthService){
    this.cartItems = this.cart.getCartItems();

  }
 
  
  removeFromCart(itemId: number) {
    this.cart.removeFromCart(itemId);
    this.cartItems = this.cart.getCartItems();

  }


  newdata: any;
  ngOnInit() {

  }
  
  getallcycle() {
    const headers = new HttpHeaders({

      'Authorization': 'Bearer ' + localStorage.getItem('token')
  
    });
    return this._http.get('http://localhost:8080/api/cycles/cart',{headers: headers});
  }



  borrowCycle(id: number, quantityToBorrow: number) {

    const requestBody = { id, count: quantityToBorrow };

    const url = `http://localhost:8080/api/cycles/${id}/cart`;

    // const headers = this.head.getHeaders();
    const headers = new HttpHeaders({

      'Authorization': 'Bearer ' + localStorage.getItem('token')
  
    });

    this._http.post(url, requestBody, { headers,responseType: 'text' }).subscribe(response => {
      this.ngOnInit();
      console.log(`Cycle with ID ${id} rented successfully.`);
    });
  }


  
  


}