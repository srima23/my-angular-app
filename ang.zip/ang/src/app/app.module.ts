import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HomepageComponent } from './homepage/homepage.component';
import { NavbarComponent } from './navbar/navbar.component';
import { RegisterpageComponent } from './registerpage/registerpage.component';
import { RentpageComponent } from './rentpage/rentpage.component';
import { RestockpageComponent } from './restockpage/restockpage.component';
import { ReturnpageComponent } from './returnpage/returnpage.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { CartpageComponent } from './cartpage/cartpage.component';

@NgModule({
  declarations: [
    AppComponent,
    CartpageComponent,
    HomepageComponent,
    NavbarComponent,
    RegisterpageComponent,
    RentpageComponent,
    RestockpageComponent,
    ReturnpageComponent,
    LoginpageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
